#mysqlpass = data_bag_item("mysql", "rtpass.json")

#mysql_service "mysqldefault" do
#   version '5.7'
#   initial_root_password mysqlpass["password"]
#   action [:create, :start]
#end


#cookbook_file "/etc/my.cnf" do
#  source "my.cnf"
#  node "0644"
#end



mysql_service 'foo' do
  port '3306'
  version '5.5'
  name 'localhost'
  initial_root_password 'password'
  action [:create, :start]
end

#mysql_config 'default' do
#  source 'my.cnf.erb'
#  notifies :restart
#  action :create
#end

#mysql_service 'default' do
# version '5.5'
#action [:create, :start]
#end

#mysql_config 'hello' do
#   instance 'default'
 #  source 'hello.conf.erb'
 #  version '5.5'
 #  action :create
#end
