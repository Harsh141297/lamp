#
# Cookbook:: apache
# Recipe:: default
#
# Copyright:: 2019, The Authors, All Rights Reserved


execute 'yum update -y'
if node[:platform] == 'centos'
 package "httpd" do
   action :install
 end

 service "httpd" do
    action [:enable, :start]
 end

end
