#
# Cookbook:: lamp_stack
# Recipe:: default
#
# Copyright:: 2020, The Authors, All Rights Reserved.

#execute "update-upgrade" do
#  command "sudo yum update && upgrade"
#  action :run
#end

